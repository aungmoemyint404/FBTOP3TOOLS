<h1 align="center">
  FACEBOOK BOT
</h1>
<h4 align="center">
  Is a simple tool for Facebook.
</h4>
<div align="center">
  <a href="https://github.com/dz-id">
    <img alt="Last Commit" src="https://img.shields.io/github/last-commit/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Language" src="https://img.shields.io/github/languages/count/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Top Language" src="https://img.shields.io/github/languages/top/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Search" src="https://img.shields.io/github/search/dz-id/fb-bot/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Repo Size" src="https://img.shields.io/github/repo-size/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Starts" src="https://img.shields.io/github/stars/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="Forks" src="https://img.shields.io/github/forks/dz-id/fb-bot.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="PHP 7.X" src="https://img.shields.io/badge/PHP-7.X-success.svg"/>
  </a>
  <a href="https://github.com/dz-id">
    <img alt="PHP CURL" src="https://img.shields.io/badge/PHP%20CURL-ALL-success.svg"/>
  </a>
</div>
<p align="center">
  Made with ❤️ by <a href="https://github.com/dz-id">DulLah</a>
</p>
<p align="center">
 <img src="https://github.com/dz-id/fb-bot/blob/master/images/menu.png" width="640" title="Menu" alt="Menu">
</p>

## Features
* Chat Messages Eraser
* Post Eraser
* FriendsList Eraser
* Photo Album Eraser
* Accept Delete Friends Request
* Mass Join Group By Search Name
* Update Status Random Caption
* Mass Chat To Friends-list
* Spam Chat Target
* Mass Leave Group
* Mass React
* Mass Comments
* Spam Comments In One Post
* Mass Posting Groups
* Cancel Request Sent
* Unblock All User

## Version
### v1.0 :
#### Changelog :
* Add Tools
### v1.1 :
#### Changelog :
* Update banner
* Fix bug mass join groups
* Add see cookies
* Add about tools
* Add spam comments in one post
* Add mass posting groups
* Add cancel request sent
* Add unblock all user

## Install script on Termux
```
pkg update && pkg upgrade
pkg install php git libicu libgnutls
git clone https://github.com/dz-id/fb-bot
```

## Run script
```
cd fb-bot
php bot.php
```

## Thank you for all
1. CLIMate Library [here](https://climate.thephpleague.com/).
2. Codeigniter [here](https://codeigniter.com/).
3. ASCII Art Generator [here](https://www.asciiart.eu/).

## Contact
1. Facebook [here](https://www.facebook.com/dulahz).
2. Telegram [here](https://t.me/DulLah).

## Donation
If you want to buy my coffee, OVO/DANA (6282320748574)
